import React, { useEffect } from 'react';
import { useState } from 'react';

const Effect = () => {
    const [count, setCount] = useState(0)

    useEffect(() => {
        console.log("COMPONENT IN MOUNT");

        return () => {
                console.log("COMPONENT UNMAUNT");
        }
    }, [])

    console.log("COMPONENT RENDER");

    return (
<div>
        <div>
            COMPONENT
        </div>
        <div>
            <span>{count}</span>
            <button
                onClick={() => setCount(prev => ++prev)}
            >
                +
            </button>
        </div>
        </div>
    );
};

export default Effect;