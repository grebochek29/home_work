import React, { memo } from 'react';

const Item = memo(({ item, setActive }) => {

    console.log("RENDER", item.title)

    return (
        <li
            onClick={() => setActive(item.id)}
            style={{
                color: item.isActive ? "green" : "black"
            }}
        >
            {item.title}
        </li>
    );
});

export default Item;
