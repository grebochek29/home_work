import React, { useCallback, useState } from 'react';
import Item from '../Item'

const initialList = [
    {
        title: "HELLO 1",
        isActive: false,
        id: 1
    },
    {
        title: "HELLO 2",
        isActive: false,
        id: 2
    },
    {
        title: "HELLO 3",
        isActive: false,
        id: 3
    }
]

const List = () => {
    const [list, setList] = useState(initialList)

    const setActive = useCallback((id) => {
        setList((prev) => {
            return prev.map(elem => {
                if (elem.id === id) {
                    return {
                        ...elem,
                        isActive: true
                    }
                } else {
                    return elem
                }
            })
        })
    }, [])

    return (
        <ul>
           {list.map(item => (
            <Item setActive={setActive} item={item} key={item.id}/>
           ))}
        </ul>
    );
};

export default List;
