import { createPortal } from 'react-dom'

const Portal = (props) => {

    const{
        children,
        container = document.body
    } = props
    return createPortal(children, container)

};

export default Portal;