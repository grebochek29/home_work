import React from 'react';

const arr = [1,2,3,4,5,6]

const JSX = () => {

    

    return (
    <>
        <div className='JSX_first_element'>
            {arr.map(elem => {
                const mult = elem * elem
                return (
                    <span key={mult}>{mult}</span>
                )
                })}
        </div>
        <div>
            {arr.map((elem, inx) => {
                <span key={inx}>{elem}</span>
            })}
        </div>
        <div>
            {
                arr.length % 2 === 0
                ?   arr.map(elem => (
                    <span key={elem}>{elem}</span>
                    ))
                :   arr.reverse().map(elem => (
                    <span key={elem}>{elem}</span>
                    ))
            }
        </div>
    </>
    );
};

export default JSX;