import React, { createContext } from 'react';

export const context = createContext({})

const ContextComp = ({ children }) => {

    const data = {
        name: "Aidar"
    }

    return (
        <context.Provider
            value={data}
        >
            {children}
        </context.Provider>
    );
};

export default ContextComp;
