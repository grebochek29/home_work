import React from 'react';

const Props = ({c, bg, title}) => {

    return (
        <button
            style={{
                color: c,
                background: bg,
            }}    
        >
            {title}
        </button>
    );
};

export default Props;