import React from 'react';

const Events = (props) => {

    const{
        btnTitle,
        placeholder,
        onClick,
        onChange,
        onBlur,
        onFocus
    } = props

    return (
        <div>
            <input 
            placeholder={placeholder}
            onChange={onChange}
            onBlur={onBlur}
            onFocus={onFocus}
            />
            <button
            onClick={onClick}
            >

                {btnTitle}
            </button>
        </div>
    );
};

export default Events;