// import React, { Component } from 'react';

// class ClassApp extends Component {
//     state = {
//         language: "en"
//     }

//     componentDidMount() {
//         console.log("Компонент появился в ДОМ")
//     }

//     componentWillUpdate() {
//         console.log("Компонент сейчас обновится")
//     }

//     componentDidUpdate() {
//         console.log("Компонент обновился")
//     }

//     componentWillUnmount() {
//         console.log("Компонент сейчас исчезнет из ДОМ")
//     }

//     componentDidCatch(error) {
//         console.log("В компоненте произошла ошибка")
//     }

//     render() {
//         return (
//             <div>
//                 {}
//             </div>
//         );
//     }
// }

// export default ClassApp;

// initialize - инициализация компонента, его состояния
// mount - при монтировании компонента
// update - при обновлении состояния, пропсов, контекста
// unmount - при демонтировании компонента
// catch - при появлении ошибки в компоненте

import React, { useState } from 'react';

const StateComp = () => {
    const [count, setCount] = useState(-1000000)

    const decrement = () => {
        setCount((prev) => prev - 1)
    }

    const increment = () => {
        setCount(prev => {
            if(prev < 10) {
                return prev + 1
            }else {
                return prev
            }
        })
    }

    return (
        <div>
            <button onClick={decrement}>-</button>
            {count}
            <button onClick={increment}>+</button>
        </div>
    );
};

export default StateComp;