import React, { useRef } from 'react';

const Reference = () => {
    const ref = useRef()

    const onClick  = () => {
        ref.current.focus()
    }
    
    return (
        <div>
            <input  ref={ref}/>
            <button
            onClick={onClick}
            >
                CLICK
                </button>
        </div>
    );
};

export default Reference;