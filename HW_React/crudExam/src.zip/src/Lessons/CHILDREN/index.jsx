import React from 'react';

const Children = ({children}) => {
    const title = "Я Родитель"

    return (
        <div>
            <div>{title}</div>
            <div>{children}</div>
        </div>
    );
};

export default Children;