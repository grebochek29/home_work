import React, {useMemo, useCallback, useState, useEffect} from 'react';
import { useContext } from 'react';
import { context } from '../CONTEXT';

const Memoizatiom = () => {

    const [count, setCount] = useState(0)
    const { name } = useContext(context)

    const money = useMemo(() => {
        return 15000 + count
    },[])

    console.log(name);

    const getMoney = useCallback(() => {
        console.log("GETMONEY UPDATE");

        return 15000 + count
    }, [count])

    return (
        <div>
            money= {getMoney()}
            {/* {count} */}
            <button onClick={() => setCount(prev => prev +1)}>+</button>
        </div>
    );
};

export default Memoizatiom;