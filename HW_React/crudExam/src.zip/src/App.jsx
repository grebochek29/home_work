import React, { Children, useEffect, useState } from 'react';
import Events from './Lessons/EVENTS/Index';
import JSX from './Lessons/JSX';
import Props from './Lessons/PROPS';
import Childrencomp from './Lessons/CHILDREN';
import Portal from './Lessons/PORTAL';
import StateComp from './Lessons/STATE';
import Effect from './Lessons/EFFECT';
import Memoizatiom from './Lessons/MEMOIZATION';
import Reference from './Lessons/REFERNCE';
import ContextComp from './Lessons/CONTEXT';
import List from './Lessons/components/List';

function App() {
  // const [isVisible, setIsVisible] = useState(true);

  // useEffect(() => {
  //   setTimeout(() => {
  //     setIsVisible(false);
  //   }, 3000);
  // }, []);

  return (
    <div className="app">
      {/* <JSX /> */}
      {/* <Props title="Add" bg="green" c="white"/> */}
      {/* <Events
                btnTitle="CLICK 1"
                placeholder="INPUT PALCEHOOLDER 1"
                onClick={(event) =>console.log("click 1")}
                onChange={(event) =>console.log("change 1", event.target.value)}
                onBlur={(event) =>console.log("blur 1")}
                onFocus={(event) =>console.log("focus 1")}
            /> */}
      {/* <Childrencomp>
                Я Ребёнок
            </Childrencomp> */}
      {/* <Portal
                container={document.head}
            >
                <button>Click</button>
            </Portal> */}
      {/* <StateComp/> */}

      {/* {isVisible && <Effect />} */}  
      {/* <ContextComp>
        <Memoizatiom />
        <Reference/>
      </ContextComp> */}
      <List/>
    </div>
  );
}

export default App;
